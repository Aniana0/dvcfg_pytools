dvcfg_pytools

:: voice.dvcfg 작성/수정을 위한 파이썬 모듈 ::

:: 소개 ::
voice.dvcfg를 파이썬에서 편하게 수정하기 위해 만든 모듈입니다.

:: 정보 ::
버전 - 1.0.0
제작 - 아니아나(Aniana0)
이메일 - aniana0gm@gmail.com

>> 사용방법과 설명은 아래의 깃허브 링크를 참고해주세요 <<
>> https://github.com/Aniana0/dvcfg_pytools <<

-------------------------------------------------
※ English translation is using a translator. ※

:: Python module for editing .dvcfg in Python ::

:: Introduction ::
This is a Python module designed for easy editing of voice.dvcfg in Python.

:: Information ::
Version - 1.0.0
Author - Aniana0
E-mail - aniana0gm@gmail.com

>> For more information and how to use it, go to this GitHub link. <<
>> https://github.com/Aniana0/dvcfg_pytools <<