from setuptools import setup

setup(
    name='dvcfg_pytools',
    version='1.0.0',
    description='Python module for editing .dvcfg in Python.',
    author='Aniana0',
    author_email='aniana0gm@gmail.com',
    url='https://github.com/Aniana0/dvcfg_pytools',
    py_modules=['dvcfg_pytools'])
